# startup.sh
echo "Running startup script..."
ls
cd folder1
ls
date
